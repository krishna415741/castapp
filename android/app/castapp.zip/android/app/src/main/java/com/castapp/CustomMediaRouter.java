package com.castapp;


import android.support.annotation.NonNull;

import com.facebook.react.bridge.Callback;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;

public class CustomMediaRouter extends ReactContextBaseJavaModule {
    CustomMediaRouter(ReactApplicationContext context) {
        super(context);
    }

    @NonNull
    @Override
    public String getName() {
        return "CustomMediaRouter";
    }

    @ReactMethod
    public void startDiscovery(String name, Callback callBack) {
        try {
            String eventId = name;
            CastOptionsProvider castOptionsProvider = new CastOptionsProvider();
            castOptionsProvider.getCastOptions();
            callBack.invoke(null, name);

        } catch(Exception e) {
            callBack.invoke("Create Event Error", e);
        }
    }



}