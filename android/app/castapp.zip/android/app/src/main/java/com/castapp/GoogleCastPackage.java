package com.castapp;

import static android.content.Context.UI_MODE_SERVICE;

import android.app.UiModeManager;
import android.content.Context;
import android.content.res.Configuration;

import com.castapp.api.RNGCCastSession;
import com.castapp.api.RNGCRemoteMediaClient;
import com.facebook.react.ReactPackage;
import com.facebook.react.bridge.JavaScriptModule;
import com.facebook.react.bridge.NativeModule;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.uimanager.ViewManager;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;
import com.castapp.api.RNGCCastContext;
import com.castapp.api.RNGCDiscoveryManager;
import com.castapp.api.RNGCSessionManager;
import com.castapp.components.RNGoogleCastButtonManager;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class GoogleCastPackage implements ReactPackage {

  @Override
  public List<NativeModule>
  createNativeModules(ReactApplicationContext reactContext) {
    List<NativeModule> modules = new ArrayList<>();

    modules.add(new RNGCCastContext(reactContext));
    modules.add(new RNGCCastSession(reactContext));
    modules.add(new RNGCDiscoveryManager(reactContext));
    modules.add(new RNGCRemoteMediaClient(reactContext));
    modules.add(new RNGCSessionManager(reactContext));

    return modules;
  }



  @Override
  public List<ViewManager>
  createViewManagers(ReactApplicationContext reactContext) {
    List<ViewManager> managers = new ArrayList<>();

    managers.add(new RNGoogleCastButtonManager());

    return managers;
  }
}
