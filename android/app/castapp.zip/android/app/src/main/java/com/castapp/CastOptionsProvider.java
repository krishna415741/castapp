package com.castapp;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;


import com.google.android.gms.cast.framework.CastOptions;
import com.google.android.gms.cast.framework.OptionsProvider;
import com.google.android.gms.cast.framework.SessionProvider;

import java.util.List;

public class CastOptionsProvider implements OptionsProvider {
    @Override
    public CastOptions getCastOptions(Context context) {
        CastOptions castOptions = new CastOptions.Builder()
                .setReceiverApplicationId(context.getString(R.string.app_id))
                .build();
        return castOptions;
    }

    @Nullable
    @Override
    public List<SessionProvider> getAdditionalSessionProviders(@NonNull Context context) {
        return null;
    }

    public CastOptions getCastOptions() {
        CastOptions castOptions = new CastOptions.Builder()
                .setReceiverApplicationId("CC1AD845")
                .build();
        return castOptions;
    }



}