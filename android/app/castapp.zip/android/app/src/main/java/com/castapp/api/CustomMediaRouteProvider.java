package com.castapp.api;

import android.annotation.SuppressLint;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.media.MediaRoute2Info;
import android.net.Uri;
import android.os.Bundle;
//import android.support.v4.media.MediaDescriptionCompat;
import android.os.SystemClock;
import android.support.v7.media.MediaItemStatus;
import android.support.v7.media.MediaRouteDescriptor;
import android.support.v7.media.MediaRouteDiscoveryRequest;
import android.support.v7.media.MediaRouter;
import android.support.v7.media.MediaSessionStatus;
import android.util.Log;
//import android.support..
//import android.support.v7.media.MediaRouteProviderDescriptor.Builder;
import androidx.mediarouter.media.MediaRouteProviderDescriptor;
import androidx.mediarouter.media.MediaRouteProviderDescriptor.Builder;
import androidx.mediarouter.media.MediaRouteProvider;

import com.amazon.whisperplay.fling.media.controller.DiscoveryController;
import com.amazon.whisperplay.fling.media.controller.RemoteMediaPlayer;
import com.amazon.whisperplay.fling.media.service.CustomMediaPlayer;
import com.amazon.whisperplay.fling.media.service.MediaPlayerInfo;
import com.amazon.whisperplay.fling.media.service.MediaPlayerStatus;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

public final class CustomMediaRouteProvider extends MediaRouteProvider {
    private static final String TAG = "FlingMediaRouteProvider";
    private static final int MAX_VOLUME = 100;
    private static final String DEFAULT_PLAYER_SERVICE_ID = "amzn.thin.pl";
    private static final long DEFAULT_TIME_OUT = 5000L;
    private static ArrayList<IntentFilter> CONTROL_FILTERS_BASIC;
    private final CustomMediaRouteProvider flingMediaRouteProvider;
    private String mRemoteServiceID;
    private DiscoveryController mController;
    private List<RemoteMediaPlayer> mDeviceList = new LinkedList();
    private List<RemoteMediaPlayer> mSelectedDeviceList = new LinkedList();




    private DiscoveryController.IDiscoveryListener mDiscovery = new DiscoveryController.IDiscoveryListener() {
        public void playerDiscovered(RemoteMediaPlayer device) {
            synchronized(mDeviceList) {
                if (mDeviceList.remove(device)) {
                    Log.i("FlingMediaRouteProvider", "Updating Device:" + device.getName());
                } else {
                    Log.i("FlingMediaRouteProvider", "Adding Device:" + device.getName());
                }

                mDeviceList.add(device);
            }

            updateDescriptor();
        }

        public List<RemoteMediaPlayer> getDevicesList(){
            return mDeviceList;
        }



        public void playerLost(RemoteMediaPlayer device) {
            synchronized(mDeviceList) {
                if (mDeviceList.contains(device)) {
                    Log.i("FlingMediaRouteProvider", "Removing Device:" + device.getName());
                    mDeviceList.remove(device);
                }
            }

            updateDescriptor();
        }

        public void discoveryFailure() {
            Log.e("FlingMediaRouteProvider", "Discovery Failure");
        }
    };

    private void updateDescriptor() {
        Runnable runnable = new Runnable() {
            public void run() {
                Builder builder = new Builder();
                synchronized(mDeviceList) {
                    Iterator var3 = mDeviceList.iterator();

                    while(true) {
                        if (!var3.hasNext()) {
                            break;
                        }

                        RemoteMediaPlayer device = (RemoteMediaPlayer)var3.next();
                        Bundle bundle = new Bundle();
                        device.getUniqueIdentifier();
                        MediaRouteDescriptor routeDescriptor;
//                        routeDescriptor = (new Builder(device.getUniqueIdentifier(), device.getName())).setDescription(device.getName()).addControlFilters( CustomMediaRouteProvider.CONTROL_FILTERS_BASIC).setPlaybackStream(3).setPlaybackType(1).setVolumeHandling(1).setVolumeMax(100).setVolume(100).setExtras(bundle).build();
//                        builder.addRoute(routeDescriptor);
                    }
                }

                MediaRouteProviderDescriptor providerDescriptor = builder.build();
                flingMediaRouteProvider.setDescriptor(providerDescriptor);
            }
        };
        flingMediaRouteProvider.getHandler().post(runnable);
    }


    public void onDiscoveryRequestChanged(MediaRouteDiscoveryRequest request) {
        Log.d("FlingMediaRouteProvider", "onDiscoveryRequestChanged called with request: " + request);
        if (request == null) {
            this.mController.stop();
            synchronized(this.mDeviceList) {
                this.mDeviceList.clear();
                this.mDeviceList.addAll(this.mSelectedDeviceList);
            }

            this.updateDescriptor();
        } else {
            this.mController.start(this.mRemoteServiceID, this.mDiscovery);
            this.updateDescriptor();
        }

    }

    private void routeControllerSelected(RemoteMediaPlayer device) {
        synchronized(this.mDeviceList) {
            this.mSelectedDeviceList.add(device);
        }
    }

    private void routeControllerUnselected(RemoteMediaPlayer device) {
        synchronized(this.mDeviceList) {
            this.mSelectedDeviceList.remove(device);
        }
    }



    public MediaRouteProvider.RouteController onCreateRouteController(String routeId) {
        synchronized(this.mDeviceList) {
            Iterator var3 = this.mDeviceList.iterator();

            while(true) {
                if (!var3.hasNext()) {
                    break;
                }

                RemoteMediaPlayer device = (RemoteMediaPlayer)var3.next();
                if (routeId.equals(device.getUniqueIdentifier())) {
                    return new CustomMediaRouteProvider.FlingRouteController(device, this);
                }
            }
        }

        Log.e("FlingMediaRouteProvider", "No matching device found for route id:" + routeId);
        return null;
    }

    static {
        IntentFilter remotePlayback = new IntentFilter();
        remotePlayback.addCategory("android.media.intent.category.REMOTE_PLAYBACK");
        remotePlayback.addAction("android.media.intent.action.PLAY");
        remotePlayback.addAction("android.media.intent.action.SEEK");
        remotePlayback.addAction("android.media.intent.action.GET_STATUS");
        remotePlayback.addAction("android.media.intent.action.PAUSE");
        remotePlayback.addAction("android.media.intent.action.RESUME");
        remotePlayback.addAction("android.media.intent.action.STOP");
        remotePlayback.addAction("android.media.intent.action.START_SESSION");
        remotePlayback.addAction("android.media.intent.action.GET_SESSION_STATUS");
        remotePlayback.addAction("android.media.intent.action.END_SESSION");
        remotePlayback.addAction("fling.media.intent.action.MUTE");
        remotePlayback.addAction("fling.media.intent.action.UNMUTE");
        remotePlayback.addAction("fling.media.intent.action.GET_IS_MUTE");
        remotePlayback.addAction("fling.media.intent.action.GET_MEDIA_INFO");
        remotePlayback.addAction("fling.media.intent.action.ACTION_SEND_COMMAND");
        remotePlayback.addAction("fling.media.intent.action.ACTION_SET_PLAYER_STYLE");
        remotePlayback.addAction("fling.media.intent.action.ACTION_GET_IS_MIME_TYPE_SUPPORTED");
        CONTROL_FILTERS_BASIC = new ArrayList();
        CONTROL_FILTERS_BASIC.add(remotePlayback);
    }


    /**
     * Creates a media route provider.
     *
     * @param context The context.
     * @param defaultBuiltInServiceId
     */
    public CustomMediaRouteProvider(Context context, String defaultBuiltInServiceId) {
        super(context);
        this.mController = new DiscoveryController(context);
        this.mRemoteServiceID = defaultBuiltInServiceId;
        this.mController.start(defaultBuiltInServiceId, this.mDiscovery);
        this.mDeviceList = getDevicesList();
        this.flingMediaRouteProvider = new CustomMediaRouteProvider(context,DEFAULT_PLAYER_SERVICE_ID);

    }

    private List<RemoteMediaPlayer> getDevicesList() {
        return mDeviceList;
    }


    public List<RemoteMediaPlayer> getDevices() {
        return mDeviceList;
    }


    private class FlingRouteController extends RouteController {
        private static final String TAG = "FlingRouteController";
        private static final String ERROR_RESUMING = "Error resuming";
        private static final String ERROR_MUTING = "Error muting";
        private static final String ERROR_SETTING_VOLUME = "Error setting volume";
        private static final String ERROR_GETTING_VOLUME = "Error getting volume";
        private static final String ERROR_ATTEMPTING_TO_ADD_STATUS_LISTENER = "Error attempting to add status listener";
        private static final String INVALID_SESSION_ID = "Invalid session ID";
        private static final String ERROR_SEEKING_TO_SPECIFIED_POSITION = "Error seeking to specified position";
        private static final String ERROR_SETTING_MEDIA_SOURCE = "Error setting media source";
        private static final String ERROR_PAUSING = "Error pausing";
        private static final String ERROR_STOPPING = "Error stopping";
        private static final String ERROR_GETTING_POSITION = "Error getting position";
        private static final String ERROR_GETTING_DURATION = "Error getting duration";
        private static final String ERROR_GETTING_STATUS = "Error getting status";
        private static final String ERROR_REMOVING_STATUS_LISTENER = "Error removing status listener";
        private static final String FAILED_TO_SEND_STATUS_UPDATE = "Failed to send status update!";
        private static final String ERROR_VOLUME_OUT_OF_RANGE = "Cannot set volume. Volume out of range.";
        private static final String ERROR_GETTING_MEDIA_INFO = "Error getting media info";
        private static final String ERROR_GETTING_METADATA_FROM_BUNDLE = "Error getting metadata from bundle";
        private static final String ERROR_SENDING_COMMAND = "Error sending command";
        private static final String ERROR_SETTING_PLAYER_STYLE = "Error setting player style";
        private static final String ERROR_GETTING_IS_MIME_TYPE_SUPPORTED = "Error getting is mime type supported";
        private static final long MONITOR_INTERVAL = 1000L;
        private int mSessionID = 0;
        private PendingIntent mSessionReceiver;
        private PendingIntent mItemUpdateReceiver;
        private RemoteMediaPlayer mDevice;
        private CustomMediaRouteProvider mProvider;
        private MediaSessionStatus mMediaSessionStatus = (new android.support.v7.media.MediaSessionStatus.Builder(2)).setQueuePaused(false).setTimestamp(SystemClock.elapsedRealtime()).build();
        private CustomMediaRouteProvider.Status mStatus = new CustomMediaRouteProvider.Status();
        private CustomMediaRouteProvider.FlingRouteController.Monitor mListener;

        public FlingRouteController(RemoteMediaPlayer device, CustomMediaRouteProvider provider) {
            this.mDevice = device;
            this.mProvider = provider;
        }

        public void onSelect() {
            this.mProvider.routeControllerSelected(this.mDevice);
        }

        public void onUnselect() {
            this.mProvider.routeControllerUnselected(this.mDevice);
        }

        public void onSetVolume(int volume) {
            if (volume >= 0 && volume <= 100) {
                double flingVolume = (double)volume / 100.0D;
                this.mDevice.setVolume(flingVolume).getAsync(new CustomMediaRouteProvider.FlingRouteController.ErrorResultHandler("Error setting volume"));
            } else {
                Log.e("FlingRouteController", "Cannot set volume. Volume out of range.");
            }

        }

        public void onUpdateVolume(final int delta) {
            this.mDevice.getVolume().getAsync(new RemoteMediaPlayer.FutureListener<Double>() {
                public void futureIsNow(Future<Double> result) {
                    try {
                        double volume = (Double)result.get();
                        if (delta > 0) {
                            volume = Math.min(volume + (double)delta, 100.0D);
                        } else {
                            volume = Math.max(volume + (double)delta, 0.0D);
                        }

                        CustomMediaRouteProvider.FlingRouteController.this.mDevice.setVolume(volume).getAsync(CustomMediaRouteProvider.FlingRouteController.this.new ErrorResultHandler("Error setting volume"));
                    } catch (ExecutionException var4) {
                        Log.e("FlingRouteController", "Error getting volume", var4.getCause());
                    } catch (Exception var5) {
                        Log.e("FlingRouteController", "Error getting volume", var5);
                    }

                }
            });
        }

        public boolean onControlRequest(Intent intent, MediaRouter.ControlRequestCallback callback) {
            String action = intent.getAction();
            if (intent.hasCategory("android.media.intent.category.REMOTE_PLAYBACK")) {
                boolean success = false;
                if (action.equals("android.media.intent.action.PLAY")) {
                    success = this.handlePlay(intent, callback);
                } else if (action.equals("android.media.intent.action.SEEK")) {
                    success = this.handleSeek(intent, callback);
                } else if (action.equals("android.media.intent.action.GET_STATUS")) {
                    success = this.handleGetStatus(intent, callback);
                } else if (action.equals("android.media.intent.action.PAUSE")) {
                    success = this.handlePause(intent, callback);
                } else if (action.equals("android.media.intent.action.RESUME")) {
                    success = this.handleResume(intent, callback);
                } else if (action.equals("android.media.intent.action.STOP")) {
                    success = this.handleStop(intent, callback);
                } else if (action.equals("android.media.intent.action.START_SESSION")) {
                    success = this.handleStartSession(intent, callback);
                } else if (action.equals("android.media.intent.action.GET_SESSION_STATUS")) {
                    success = this.handleGetSessionStatus(intent, callback);
                } else if (action.equals("android.media.intent.action.END_SESSION")) {
                    success = this.handleEndSession(intent, callback);
                } else if (action.equals("fling.media.intent.action.MUTE")) {
                    success = this.handleMute(intent, callback, true);
                } else if (action.equals("fling.media.intent.action.UNMUTE")) {
                    success = this.handleMute(intent, callback, false);
                } else if (action.equals("fling.media.intent.action.GET_IS_MUTE")) {
                    success = this.handleGetIsMute(intent, callback);
                } else if (action.equals("fling.media.intent.action.GET_MEDIA_INFO")) {
                    success = this.handleGetMediaInfo(intent, callback);
                } else if (action.equals("fling.media.intent.action.ACTION_SEND_COMMAND")) {
                    success = this.handleSendCommand(intent, callback);
                } else if (action.equals("fling.media.intent.action.ACTION_SET_PLAYER_STYLE")) {
                    success = this.handleSetPlayerStyle(intent, callback);
                } else if (action.equals("fling.media.intent.action.ACTION_GET_IS_MIME_TYPE_SUPPORTED")) {
                    success = this.handleGetIsMimeTypeSupported(intent, callback);
                }

                return success;
            } else {
                return false;
            }
        }

        private boolean handleGetIsMimeTypeSupported(Intent intent, final MediaRouter.ControlRequestCallback callback) {
            String mimeType = intent.getStringExtra("fling.media.intent.extra.MIME_TYPE");
            this.mDevice.isMimeTypeSupported(mimeType).getAsync(new RemoteMediaPlayer.FutureListener<Boolean>() {
                public void futureIsNow(Future<Boolean> result) {
                    Bundle bundlex;
                    try {
                        Bundle bundle = new Bundle();
                        bundle.putBoolean("fling.media.intent.extra.IS_MIME_TYPE_SUPPORTED", (Boolean)result.get());
                        callback.onResult(bundle);
                    } catch (ExecutionException var4) {
                        bundlex = new Bundle();
                        Log.e("FlingRouteController", "Error getting is mime type supported", var4.getCause());
                        callback.onError("Error getting is mime type supported", bundlex);
                    } catch (Exception var5) {
                        bundlex = new Bundle();
                        Log.e("FlingRouteController", "Error getting is mime type supported", var5);
                        callback.onError("Error getting is mime type supported", bundlex);
                    }

                }
            });
            return true;
        }

        private boolean handleSetPlayerStyle(Intent intent, final MediaRouter.ControlRequestCallback callback) {
            String style = intent.getStringExtra("fling.media.intent.extra.STYLE_JSON");
            final Bundle bundle = new Bundle();
            this.mDevice.setPlayerStyle(style).getAsync(new RemoteMediaPlayer.FutureListener<Void>() {
                public void futureIsNow(Future<Void> result) {
                    try {
                        result.get();
                        callback.onResult(bundle);
                    } catch (ExecutionException var3) {
                        Log.e("FlingRouteController", "Error setting player style", var3.getCause());
                        callback.onError("Error setting player style", bundle);
                    } catch (Exception var4) {
                        Log.e("FlingRouteController", "Error setting player style", var4);
                        callback.onError("Error setting player style", bundle);
                    }

                }
            });
            return true;
        }

        private boolean handleSendCommand(Intent intent, final MediaRouter.ControlRequestCallback callback) {
            String command = intent.getStringExtra("fling.media.intent.extra.COMMAND");
            final Bundle bundle = new Bundle();
            this.mDevice.sendCommand(command).getAsync(new RemoteMediaPlayer.FutureListener<Void>() {
                public void futureIsNow(Future<Void> result) {
                    try {
                        result.get();
                        callback.onResult(bundle);
                    } catch (ExecutionException var3) {
                        Log.e("FlingRouteController", "Error sending command", var3.getCause());
                        callback.onError("Error sending command", bundle);
                    } catch (Exception var4) {
                        Log.e("FlingRouteController", "Error sending command", var4);
                        callback.onError("Error sending command", bundle);
                    }

                }
            });
            return true;
        }

        private void updateBundleFromJSON(Bundle bundle, JSONObject json) throws JSONException {
            Iterator keys = json.keys();

            while(true) {
                while(keys.hasNext()) {
                    String key = (String)keys.next();
                    if (json.get(key) instanceof JSONObject) {
                        Bundle subBundle = new Bundle();
                        bundle.putBundle(key, subBundle);
                        this.updateBundleFromJSON(subBundle, (JSONObject)json.get(key));
                    } else if (!key.equals("android.media.metadata.DISC_NUMBER") && !key.equals("android.media.metadata.TRACK_NUMBER") && !key.equals("android.media.metadata.YEAR")) {
                        if (key.equals("android.media.metadata.DURATION")) {
                            bundle.putLong(key, json.getLong(key));
                        } else if (key.equals("title") && this.mProvider.mRemoteServiceID.equals("amzn.thin.pl")) {
                            bundle.putString("android.media.metadata.TITLE", json.getString(key));
                        } else {
                            bundle.putString(key, json.getString(key));
                        }
                    } else {
                        bundle.putInt(key, json.getInt(key));
                    }
                }

                return;
            }
        }

        private boolean handleGetMediaInfo(Intent intent, final MediaRouter.ControlRequestCallback callback) {
            final Bundle bundle = new Bundle();
            this.mDevice.getMediaInfo().getAsync(new RemoteMediaPlayer.FutureListener<MediaPlayerInfo>() {
                public void futureIsNow(Future<MediaPlayerInfo> result) {
                    try {
                        MediaPlayerInfo mediaInfo = (MediaPlayerInfo)result.get();
                        String source = mediaInfo.getSource();
                        bundle.putString("fling.media.intent.extra.SOURCE", source);
                        JSONObject metaDataJSON = new JSONObject(mediaInfo.getMetadata());
                        Bundle mediaInfoBundle = new Bundle();
                        CustomMediaRouteProvider.FlingRouteController.this.updateBundleFromJSON(mediaInfoBundle, metaDataJSON);
                        bundle.putBundle("android.media.intent.extra.ITEM_METADATA", mediaInfoBundle);
                        String extra = mediaInfo.getExtra();
                        bundle.putString("fling.media.intent.extra.EXTRA_MEDIA_INFO", extra);
                        callback.onResult(bundle);
                    } catch (ExecutionException var7) {
                        Log.e("FlingRouteController", "Error getting media info", var7.getCause());
                        callback.onError("Error getting media info", bundle);
                    } catch (Exception var8) {
                        Log.e("FlingRouteController", "Error getting media info", var8);
                        callback.onError("Error getting media info", bundle);
                    }

                }
            });
            return true;
        }

        private boolean handleMute(Intent intent, final MediaRouter.ControlRequestCallback callback, boolean isMute) {
            final Bundle bundle = new Bundle();
            this.mDevice.setMute(isMute).getAsync(new RemoteMediaPlayer.FutureListener<Void>() {
                public void futureIsNow(Future<Void> result) {
                    try {
                        result.get();
                        callback.onResult(bundle);
                    } catch (ExecutionException var3) {
                        Log.e("FlingRouteController", "Error muting", var3.getCause());
                        callback.onError("Error muting", bundle);
                    } catch (Exception var4) {
                        Log.e("FlingRouteController", "Error muting", var4);
                        callback.onError("Error muting", bundle);
                    }

                }
            });
            return true;
        }

        private boolean handleGetIsMute(Intent intent, final MediaRouter.ControlRequestCallback callback) {
            this.mDevice.isMute().getAsync(new RemoteMediaPlayer.FutureListener<Boolean>() {
                public void futureIsNow(Future<Boolean> result) {
                    Bundle bundle;
                    try {
                        boolean isMute = (Boolean)result.get();
                        bundle = new Bundle();
                        bundle.putBoolean("fling.media.intent.extra.IS_MUTE", isMute);
                        callback.onResult(bundle);
                    } catch (ExecutionException var4) {
                        Log.e("FlingRouteController", "Error muting", var4.getCause());
                        bundle = new Bundle();
                        callback.onError("Error muting", bundle);
                    } catch (Exception var5) {
                        Log.e("FlingRouteController", "Error muting", var5);
                        bundle = new Bundle();
                        callback.onError("Error muting", bundle);
                    }

                }
            });
            return true;
        }

        private void setSessionReceiver(PendingIntent pendingIntent) {
            this.mSessionReceiver = pendingIntent;
        }

        private void setItemUpdateReceiver(PendingIntent pendingIntent) {
            this.mItemUpdateReceiver = pendingIntent;
            if (this.mListener != null) {
                try {
                    this.mDevice.removeStatusListener(this.mListener).get(5000L, TimeUnit.MILLISECONDS);
                } catch (InterruptedException var6) {
                    Log.e("FlingRouteController", "Error removing status listener", var6);
                } catch (ExecutionException var7) {
                    Log.e("FlingRouteController", "Error removing status listener", var7);
                } catch (TimeoutException var8) {
                    Log.e("FlingRouteController", "Error removing status listener", var8);
                }
            }

            this.mListener = new CustomMediaRouteProvider.FlingRouteController.Monitor();

            try {
                this.mDevice.addStatusListener(this.mListener).get(5000L, TimeUnit.MILLISECONDS);
                this.mDevice.setPositionUpdateInterval(1000L).get(5000L, TimeUnit.MILLISECONDS);
            } catch (InterruptedException var3) {
                Log.e("FlingRouteController", "Error attempting to add status listener", var3);
            } catch (ExecutionException var4) {
                Log.e("FlingRouteController", "Error attempting to add status listener", var4);
            } catch (TimeoutException var5) {
                Log.e("FlingRouteController", "Error attempting to add status listener", var5);
            }

        }

        private boolean handleStartSession(Intent intent, MediaRouter.ControlRequestCallback callback) {
            ++this.mSessionID;
            this.mMediaSessionStatus = (new android.support.v7.media.MediaSessionStatus.Builder(0)).setQueuePaused(false).setTimestamp(SystemClock.elapsedRealtime()).build();
            PendingIntent pendingIntent = (PendingIntent)intent.getParcelableExtra("android.media.intent.extra.SESSION_STATUS_UPDATE_RECEIVER");
            if (pendingIntent != null) {
                this.setSessionReceiver(pendingIntent);
            }

            this.sendToSessionReceiver();
            Bundle bundle = new Bundle();
            bundle.putString("android.media.intent.extra.SESSION_ID", String.valueOf(this.mSessionID));
            bundle.putBundle("android.media.intent.extra.SESSION_STATUS", this.getMediaSessionStatus().asBundle());
            callback.onResult(bundle);
            return true;
        }

        private Bundle handleSessionAndCreateResponseBundle(Intent intent, MediaRouter.ControlRequestCallback callback) {
            String sessionID = intent.getStringExtra("android.media.intent.extra.SESSION_ID");
            if (sessionID != null && this.mSessionID != Integer.parseInt(sessionID)) {
                Bundle bundle = new Bundle();
                bundle.putString("android.media.intent.extra.ERROR_CODE", "Invalid session ID");
                Log.e("FlingRouteController", "Invalid session ID");
                callback.onError("Invalid session ID", bundle);
                return null;
            } else {
                if (sessionID == null) {
                    ++this.mSessionID;
                }

                PendingIntent pendingIntent = (PendingIntent)intent.getParcelableExtra("android.media.intent.extra.ITEM_STATUS_UPDATE_RECEIVER");
                if (pendingIntent != null) {
                    this.setItemUpdateReceiver(pendingIntent);
                }

                Bundle bundlex = new Bundle();
                bundlex.putString("android.media.intent.extra.SESSION_ID", String.valueOf(this.mSessionID));
                bundlex.putBundle("android.media.intent.extra.SESSION_STATUS", this.getMediaSessionStatus().asBundle());
                bundlex.putString("android.media.intent.extra.ITEM_ID", "0");
                bundlex.putBundle("android.media.intent.extra.ITEM_STATUS", this.getMediaStatus().asBundle());
                return bundlex;
            }
        }

        private void seek(long position, final MediaRouter.ControlRequestCallback callback, final Bundle bundleResult) {
            this.mDevice.seek(CustomMediaPlayer.PlayerSeekMode.Absolute, position).getAsync(new RemoteMediaPlayer.FutureListener<Void>() {
                public void futureIsNow(Future<Void> result) {
                    try {
                        result.get();
                        callback.onResult(bundleResult);
                    } catch (ExecutionException var3) {
                        callback.onError("Error seeking to specified position", bundleResult);
                        Log.e("FlingRouteController", "Error seeking to specified position", var3.getCause());
                    } catch (Exception var4) {
                        callback.onError("Error seeking to specified position", bundleResult);
                        Log.e("FlingRouteController", "Error seeking to specified position", var4);
                    }

                }
            });
        }

        private JSONObject getJSONFromBundle(Bundle bundle) throws JSONException {
            JSONObject json = new JSONObject();
            Set<String> keys = bundle.keySet();
            Iterator var4 = keys.iterator();

            while(true) {
                while(var4.hasNext()) {
                    String key = (String)var4.next();
                    if (bundle.get(key) instanceof Bundle) {
                        json.put(key, this.getJSONFromBundle((Bundle)bundle.get(key)));
                    } else if (!(bundle.get(key) instanceof ArrayList)) {
                        if (key.equals("android.media.metadata.TITLE") && this.mProvider.mRemoteServiceID.equals("amzn.thin.pl")) {
                            json.put("title", bundle.get(key));
                        } else if (key.equals("android.media.metadata.ARTWORK_URI") && this.mProvider.mRemoteServiceID.equals("amzn.thin.pl")) {
                            json.put("poster", bundle.get(key));
                        } else {
                            json.put(key, bundle.get(key));
                        }
                    } else {
                        JSONArray array = new JSONArray();
                        Iterator var7 = ((ArrayList)bundle.get(key)).iterator();

                        while(var7.hasNext()) {
                            Bundle arrayBundle = (Bundle)var7.next();
                            array.put(this.getJSONFromBundle(arrayBundle));
                        }

                        json.put(key, array);
                    }
                }

                return json;
            }
        }

        private boolean handlePlay(Intent intent, final MediaRouter.ControlRequestCallback callback) {
            final Bundle bundleResult = this.handleSessionAndCreateResponseBundle(intent, callback);
            if (bundleResult != null) {
                Uri uri = intent.getData();
                final long contentPosition = intent.getLongExtra("android.media.intent.extra.ITEM_POSITION", 0L);
                Bundle metadata = intent.getBundleExtra("android.media.intent.extra.ITEM_METADATA");

                JSONObject metadataJSON;
                try {
                    metadataJSON = this.getJSONFromBundle(metadata);
                } catch (JSONException var10) {
                    Log.e("FlingRouteController", "Error getting metadata from bundle", var10.getCause());
                    callback.onError("Error getting metadata from bundle", bundleResult);
                    return true;
                }

                this.mDevice.setMediaSource(uri.toString(), metadataJSON.toString(), true, false).getAsync(new RemoteMediaPlayer.FutureListener<Void>() {
                    public void futureIsNow(Future<Void> result) {
                        try {
                            result.get();
                            if (contentPosition != 0L) {
                                CustomMediaRouteProvider.FlingRouteController.this.seek(contentPosition, callback, bundleResult);
                            } else {
                                callback.onResult(bundleResult);
                            }
                        } catch (ExecutionException var3) {
                            callback.onError("Error setting media source", bundleResult);
                            Log.e("FlingRouteController", "Error setting media source", var3.getCause());
                        } catch (Exception var4) {
                            callback.onError("Error setting media source", bundleResult);
                            Log.e("FlingRouteController", "Error setting media source", var4);
                        }

                    }
                });
            }

            return true;
        }

        private boolean checkSessionID(Intent intent, MediaRouter.ControlRequestCallback callback) {
            String sessionID = intent.getStringExtra("android.media.intent.extra.SESSION_ID");
            if (sessionID != null && this.mSessionID == Integer.parseInt(sessionID)) {
                return true;
            } else {
                Bundle bundle = new Bundle();
                bundle.putString("android.media.intent.extra.ERROR_CODE", "Invalid session ID");
                Log.e("FlingRouteController", "Invalid session ID");
                callback.onError("Invalid session ID", bundle);
                return false;
            }
        }

        private boolean handleSeek(Intent intent, MediaRouter.ControlRequestCallback callback) {
            if (this.checkSessionID(intent, callback)) {
                long contentPosition = intent.getLongExtra("android.media.intent.extra.ITEM_POSITION", 0L);
                Bundle bundle = new Bundle();
                bundle.putBundle("android.media.intent.extra.SESSION_STATUS", this.getMediaSessionStatus().asBundle());
                bundle.putBundle("android.media.intent.extra.ITEM_STATUS", this.getMediaStatus().asBundle());
                this.seek(contentPosition, callback, bundle);
            }

            return true;
        }

        private boolean handlePause(Intent intent, final MediaRouter.ControlRequestCallback callback) {
            if (this.checkSessionID(intent, callback)) {
                final Bundle bundle = new Bundle();
                bundle.putBundle("android.media.intent.extra.SESSION_STATUS", this.getMediaSessionStatus().asBundle());
                this.mDevice.pause().getAsync(new RemoteMediaPlayer.FutureListener<Void>() {
                    public void futureIsNow(Future<Void> result) {
                        try {
                            result.get();
                            CustomMediaRouteProvider.FlingRouteController.this.mMediaSessionStatus = (new android.support.v7.media.MediaSessionStatus.Builder(CustomMediaRouteProvider.FlingRouteController.this.mMediaSessionStatus.getSessionState())).setQueuePaused(true).setTimestamp(SystemClock.elapsedRealtime()).build();
                            CustomMediaRouteProvider.FlingRouteController.this.sendToSessionReceiver();
                            callback.onResult(bundle);
                        } catch (ExecutionException var3) {
                            callback.onError("Error pausing", bundle);
                            Log.e("FlingRouteController", "Error pausing", var3.getCause());
                        } catch (Exception var4) {
                            callback.onError("Error pausing", bundle);
                            Log.e("FlingRouteController", "Error pausing", var4);
                        }

                    }
                });
            }

            return true;
        }

        private boolean handleResume(Intent intent, final MediaRouter.ControlRequestCallback callback) {
            if (this.checkSessionID(intent, callback)) {
                final Bundle bundle = new Bundle();
                bundle.putBundle("android.media.intent.extra.SESSION_STATUS", this.getMediaSessionStatus().asBundle());
                this.mDevice.play().getAsync(new RemoteMediaPlayer.FutureListener<Void>() {
                    public void futureIsNow(Future<Void> result) {
                        try {
                            result.get();
                            CustomMediaRouteProvider.FlingRouteController.this.mMediaSessionStatus = (new android.support.v7.media.MediaSessionStatus.Builder(CustomMediaRouteProvider.FlingRouteController.this.mMediaSessionStatus.getSessionState())).setQueuePaused(false).setTimestamp(SystemClock.elapsedRealtime()).build();
                            CustomMediaRouteProvider.FlingRouteController.this.sendToSessionReceiver();
                            callback.onResult(bundle);
                        } catch (ExecutionException var3) {
                            callback.onError("Error resuming", bundle);
                            Log.e("FlingRouteController", "Error resuming", var3.getCause());
                        } catch (Exception var4) {
                            callback.onError("Error resuming", bundle);
                            Log.e("FlingRouteController", "Error resuming", var4);
                        }

                    }
                });
            }

            return true;
        }

        private boolean handleStop(Intent intent, final MediaRouter.ControlRequestCallback callback) {
            if (this.checkSessionID(intent, callback)) {
                final Bundle bundle = new Bundle();
                bundle.putBundle("android.media.intent.extra.SESSION_STATUS", this.getMediaSessionStatus().asBundle());
                bundle.putBundle("android.media.intent.extra.ITEM_STATUS", this.getMediaStatus().asBundle());
                this.mStatus.clear();
                this.mDevice.stop().getAsync(new RemoteMediaPlayer.FutureListener<Void>() {
                    public void futureIsNow(Future<Void> result) {
                        try {
                            result.get();
                            callback.onResult(bundle);
                        } catch (ExecutionException var3) {
                            callback.onError("Error stopping", bundle);
                            Log.e("FlingRouteController", "Error stopping", var3.getCause());
                        } catch (Exception var4) {
                            callback.onError("Error stopping", bundle);
                            Log.e("FlingRouteController", "Error stopping", var4);
                        }

                    }
                });
            }

            return true;
        }

        private Bundle getStatusResponse() {
            Bundle bundle = new Bundle();
            bundle.putBundle("android.media.intent.extra.SESSION_STATUS", this.getMediaSessionStatus().asBundle());
            bundle.putBundle("android.media.intent.extra.ITEM_STATUS", this.getMediaStatus().asBundle());
            return bundle;
        }

        private void getDuration(final MediaRouter.ControlRequestCallback callback) {
            this.mDevice.getDuration().getAsync(new RemoteMediaPlayer.FutureListener<Long>() {
                public void futureIsNow(Future<Long> result) {
                    try {
                        CustomMediaRouteProvider.FlingRouteController.this.mStatus.mDuration = (Long)result.get();
                    } catch (ExecutionException var3) {
                        Log.e("FlingRouteController", "Error getting duration", var3.getCause());
                    } catch (Exception var4) {
                        Log.e("FlingRouteController", "Error getting duration", var4);
                    }

                    Bundle bundle = CustomMediaRouteProvider.FlingRouteController.this.getStatusResponse();
                    callback.onResult(bundle);
                }
            });
        }

        private void getPosition(final MediaRouter.ControlRequestCallback callback) {
            this.mDevice.getPosition().getAsync(new RemoteMediaPlayer.FutureListener<Long>() {
                public void futureIsNow(Future<Long> result) {
                    try {
                        CustomMediaRouteProvider.FlingRouteController.this.mStatus.mPosition = (Long)result.get();
                    } catch (ExecutionException var3) {
                        Log.e("FlingRouteController", "Error getting position", var3.getCause());
                    } catch (Exception var4) {
                        Log.e("FlingRouteController", "Error getting position", var4);
                    }

                    CustomMediaRouteProvider.FlingRouteController.this.getDuration(callback);
                }
            });
        }

        private boolean handleGetStatus(Intent intent, final MediaRouter.ControlRequestCallback callback) {
            if (this.checkSessionID(intent, callback)) {
                this.mDevice.getStatus().getAsync(new RemoteMediaPlayer.FutureListener<MediaPlayerStatus>() {
                    public void futureIsNow(Future<MediaPlayerStatus> result) {
                        Bundle bundle;
                        try {
                            MediaPlayerStatus mediaPlayerStatus = (MediaPlayerStatus)result.get();
                            CustomMediaRouteProvider.FlingRouteController.this.mStatus.mState = mediaPlayerStatus.getState();
                            if (CustomMediaRouteProvider.FlingRouteController.this.mStatus.mState != MediaPlayerStatus.MediaState.NoSource && CustomMediaRouteProvider.FlingRouteController.this.mStatus.mState != MediaPlayerStatus.MediaState.PreparingMedia) {
                                CustomMediaRouteProvider.FlingRouteController.this.getPosition(callback);
                            }
                        } catch (ExecutionException var4) {
                            bundle = CustomMediaRouteProvider.FlingRouteController.this.getStatusResponse();
                            callback.onError("Error getting status", bundle);
                            Log.e("FlingRouteController", "Error getting status", var4.getCause());
                        } catch (Exception var5) {
                            bundle = CustomMediaRouteProvider.FlingRouteController.this.getStatusResponse();
                            callback.onError("Error getting status", bundle);
                            Log.e("FlingRouteController", "Error getting status", var5);
                        }

                    }
                });
            }

            return true;
        }

        private boolean handleGetSessionStatus(Intent intent, MediaRouter.ControlRequestCallback callback) {
            if (this.checkSessionID(intent, callback)) {
                Bundle bundle = new Bundle();
                bundle.putBundle("android.media.intent.extra.SESSION_STATUS", this.getMediaSessionStatus().asBundle());
                callback.onResult(bundle);
            }

            return true;
        }

        private boolean handleEndSession(Intent intent, final MediaRouter.ControlRequestCallback callback) {
            if (this.checkSessionID(intent, callback)) {
                this.mMediaSessionStatus = (new android.support.v7.media.MediaSessionStatus.Builder(1)).setQueuePaused(false).setTimestamp(SystemClock.elapsedRealtime()).build();
                this.sendToSessionReceiver();
                this.mSessionReceiver = null;
                final Bundle bundle = new Bundle();
                bundle.putBundle("android.media.intent.extra.SESSION_STATUS", this.getMediaSessionStatus().asBundle());
                this.mStatus.clear();
                if (this.mListener != null) {
                    this.mDevice.removeStatusListener(this.mListener).getAsync(new RemoteMediaPlayer.FutureListener<Void>() {
                        public void futureIsNow(Future<Void> result) {
                            try {
                                result.get();
                                CustomMediaRouteProvider.FlingRouteController.this.mListener = null;
                                callback.onResult(bundle);
                            } catch (ExecutionException var3) {
                                callback.onError("Error removing status listener", bundle);
                                Log.e("FlingRouteController", "Error removing status listener", var3.getCause());
                            } catch (Exception var4) {
                                callback.onError("Error removing status listener", bundle);
                                Log.e("FlingRouteController", "Error removing status listener", var4);
                            }

                        }
                    });
                } else {
                    callback.onResult(bundle);
                }

                this.mItemUpdateReceiver = null;
            }

            return true;
        }

        private void sendToSessionReceiver() {
            if (this.mSessionReceiver != null) {
                synchronized(this.mStatus) {
                    Intent intent = new Intent();
                    intent.putExtra("android.media.intent.extra.SESSION_ID", String.valueOf(this.mSessionID));
                    intent.putExtra("android.media.intent.extra.SESSION_STATUS", this.getMediaSessionStatus().asBundle());

                    try {
                        this.mSessionReceiver.send(CustomMediaRouteProvider.this.getContext(), 0, intent);
                    } catch (PendingIntent.CanceledException var5) {
                        Log.e("FlingRouteController", "Failed to send status update!");
                    }
                }
            }

        }

        private void sendToItemUpdateReceiver() {
            if (this.mItemUpdateReceiver != null) {
                synchronized(this.mStatus) {
                    Intent intent = new Intent();
                    intent.putExtra("android.media.intent.extra.SESSION_ID", String.valueOf(this.mSessionID));
                    intent.putExtra("android.media.intent.extra.ITEM_ID", "0");
                    intent.putExtra("android.media.intent.extra.ITEM_STATUS", this.getMediaStatus().asBundle());
                    intent.putExtra("android.media.intent.extra.SESSION_STATUS", this.getMediaSessionStatus().asBundle());

                    try {
                        this.mItemUpdateReceiver.send(CustomMediaRouteProvider.this.getContext(), 0, intent);
                    } catch (PendingIntent.CanceledException var5) {
                        Log.e("FlingRouteController", "Failed to send status update!");
                    }
                }
            }

        }

        private MediaItemStatus getMediaStatus() {
            byte playbackState;
            switch(this.mStatus.mState) {
                case NoSource:
                case ReadyToPlay:
                    playbackState = 0;
                    break;
                case Finished:
                    playbackState = 4;
                    break;
                case Error:
                    playbackState = 7;
                    break;
                case PreparingMedia:
                case Seeking:
                    playbackState = 3;
                    break;
                case Playing:
                    playbackState = 1;
                    break;
                case Paused:
                    playbackState = 2;
                    break;
                default:
                    playbackState = 7;
            }

            return (new android.support.v7.media.MediaItemStatus.Builder(playbackState)).setContentPosition(this.mStatus.mPosition).setContentDuration(this.mStatus.mDuration).setTimestamp(this.mStatus.mTimeStamp).build();
        }

        private MediaSessionStatus getMediaSessionStatus() {
            return this.mMediaSessionStatus;
        }

        private class ErrorResultHandler implements RemoteMediaPlayer.FutureListener<Void> {
            private String mMsg;
            private boolean mExtend;

            ErrorResultHandler(String msg) {
                this(msg, false);
            }

            ErrorResultHandler(String msg, boolean extend) {
                this.mMsg = msg;
                this.mExtend = extend;
            }

            public void futureIsNow(Future<Void> result) {
                try {
                    result.get();
                } catch (ExecutionException var3) {
                    Log.e("FlingRouteController", this.mMsg + (this.mExtend ? var3.getCause().getMessage() : ""));
                } catch (Exception var4) {
                    Log.e("FlingRouteController", this.mMsg + (this.mExtend ? var4.getMessage() : ""));
                }

            }
        }

        private class Monitor implements CustomMediaPlayer.StatusListener {
            private Monitor() {
            }

            @SuppressLint({"NewApi"})
            public void onStatusChange(MediaPlayerStatus status, long position) {
                if (FlingRouteController.this.mDevice != null) {
                    synchronized(FlingRouteController.this.mStatus) {
                        FlingRouteController.this.mStatus.mState = status.getState();
                        FlingRouteController.this.mStatus.mPosition = position;
                    }

                    FlingRouteController.this.sendToItemUpdateReceiver();
                }

            }
        }
    }


    private static class Status {
        public long mPosition;
        public long mDuration;
        public long mTimeStamp;
        public MediaPlayerStatus.MediaState mState;

        private Status() {
            this.mState = MediaPlayerStatus.MediaState.NoSource;
        }

        public synchronized void clear() {
            this.mPosition = -1L;
            this.mDuration = -1L;
            this.mTimeStamp = SystemClock.elapsedRealtime();
            this.mState = MediaPlayerStatus.MediaState.NoSource;
        }
    }

}
