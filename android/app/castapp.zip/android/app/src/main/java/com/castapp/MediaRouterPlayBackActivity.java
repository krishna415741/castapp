package com.castapp;

import android.os.Bundle;
import android.support.v4.view.MenuItemCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.app.MediaRouteActionProvider;
import android.support.v7.media.MediaControlIntent;
import android.support.v7.media.MediaRouteSelector;
import android.support.v7.media.MediaRouter;
import android.support.v7.media.RemotePlaybackClient;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;



public class MediaRouterPlayBackActivity {
    public class MediaRouterPlaybackActivity extends AppCompatActivity {
        private MediaRouter mediaRouter;
        private MediaRouteSelector mSelector;

        // Variables to hold the currently selected route and its playback client
        private MediaRouter.RouteInfo mRoute;
        private RemotePlaybackClient remotePlaybackClient;

        // Define the Callback object and its methods, save the object in a class variable
        private final MediaRouter.Callback mediaRouterCallback =
                new MediaRouter.Callback() {

                    @Override
                    public void onRouteSelected(MediaRouter router, MediaRouter.RouteInfo route) {
                        Log.d("SUCCESS", "onRouteSelected: route=" + route);

                        if (route.supportsControlCategory(
                                MediaControlIntent.CATEGORY_REMOTE_PLAYBACK)){
                            // Stop local playback (if necessary)
                            // ...

                            // Save the new route
                            mRoute = route;

                            // Attach a new playback client
                            remotePlaybackClient = new RemotePlaybackClient(null, mRoute);

                            // Start remote playback (if necessary)
                            // ...
                        }
                    }

                    @Override
                    public void onRouteUnselected(MediaRouter router, MediaRouter.RouteInfo route, int reason) {
                        Log.d("SUCCESS", "onRouteUnselected: route=" + route);

                        if (route.supportsControlCategory(
                                MediaControlIntent.CATEGORY_REMOTE_PLAYBACK)){

                            // Changed route: tear down previous client
                            if (mRoute != null && remotePlaybackClient != null) {
                                remotePlaybackClient.release();
                                remotePlaybackClient = null;
                            }

                            // Save the new route
                            mRoute = route;

                            if (reason != MediaRouter.UNSELECT_REASON_ROUTE_CHANGED) {
                                // Resume local playback  (if necessary)
                                // ...
                            }
                        }
                    }
                };


        @Override
        public boolean onCreateOptionsMenu(Menu menu) {
            super.onCreateOptionsMenu(menu);

            // Inflate the menu and configure the media router action provider.
            getMenuInflater().inflate(R.menu.cast_expanded_controller_menu, menu);

            // Attach the MediaRouteSelector to the menu item
            MenuItem mediaRouteMenuItem = menu.findItem(R.id.media_route_menu_item);
            MediaRouteActionProvider mediaRouteActionProvider =
                    (MediaRouteActionProvider) MenuItemCompat.getActionProvider(
                            mediaRouteMenuItem);
            // Attach the MediaRouteSelector that you built in onCreate()
            mediaRouteActionProvider.setRouteSelector(mSelector);

            // Return true to show the menu.
            return true;
        }

        // Retain a pointer to the MediaRouter
        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.menu);
//            setContentView(R.layout.activity_main);

            // Create a route selector for the type of routes your app supports.
            mSelector = new MediaRouteSelector.Builder()
                    // These are the framework-supported intents
                    .addControlCategory(MediaControlIntent.CATEGORY_REMOTE_PLAYBACK)
                    .addControlCategory(MediaControlIntent.CATEGORY_LIVE_VIDEO)
                    .addControlCategory(MediaControlIntent.CATEGORY_LIVE_AUDIO)

                    .build();
            // Get the media router service.
            mediaRouter = MediaRouter.getInstance(this);

        }

        // Use this callback to run your MediaRouteSelector to generate the list of available media routes
        @Override
        public void onStart() {
            mediaRouter.addCallback(mSelector, mediaRouterCallback,
                    MediaRouter.CALLBACK_FLAG_REQUEST_DISCOVERY);
            super.onStart();
        }

        // Remove the selector on stop to tell the media router that it no longer
        // needs to discover routes for your app.
        @Override
        public void onStop() {
            mediaRouter.removeCallback(mediaRouterCallback);
            super.onStop();
        }

    }
}
